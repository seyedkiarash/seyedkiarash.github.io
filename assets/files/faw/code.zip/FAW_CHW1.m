clc; clear; close all;
%% 1. 
epcilone_val = 8.854e-12; 
miu_val = 4*pi*1e-7;
c = 3e8;
E0_val = 1; 
H0_val = 1/377; 
syms x y z t r phi w epcilone miu E0 H0 a b R

%% 2. (UI State Machine)
step = 1;

while step <= 3
    switch step
        case 1 
            clc;
            disp('====================================================');
            disp('            انتخاب نوع ساختار موجبر');
            disp('====================================================');
            disp('1: موجبر صفحه موازی (Parallel Plate)');
            disp('2: موجبر مستطیلی (Rectangular)');
            disp('3: موجبر دایروی (Circular)');
            disp('4: فیبر نوری (Optical Fiber)');
            disp('====================================================');
            wg_type = input('لطفاً شماره ساختار را وارد کنید (1-4): ');
            
            if isempty(wg_type) || wg_type < 1 || wg_type > 4
                disp('❌ ورودی نامعتبر! لطفاً عددی بین 1 تا 4 انتخاب کنید.');
                pause(1.5);
                continue;
            end
            step = 2;
            
        case 2 
            clc;
            disp('====================================================');
            disp('               تعیین فرکانس کاری');
            disp('  [جهت بازگشت به انتخاب ساختار، عدد -1 را وارد کنید]');
            disp('====================================================');
            f = input('فرکانس کاری (Hz) [مثال 5e10 یا -1 برای بازگشت]: ');
            
            if isempty(f)
                disp('❌ ورودی نامعتبر!'); pause(1); continue;
            end
            if f == -1
                step = 1; 
                continue;
            end
            if f <= 0
                disp('❌ فرکانس باید یک عدد مثبت باشد!'); pause(1.5); continue;
            end
            
            w_val = 2*pi*f;
            step = 3;
            
        case 3 
            clc;
            disp('====================================================');
            disp('            مشخصات هندسی و مود موجبر');
            disp('  [در هر ورودی، با وارد کردن -1 به انتخاب فرکانس برمی‌گردید]');
            disp('====================================================');
            
            switch wg_type
                case 1 
                    b_val = input('فاصله بین صفحات b (متر): ');
                    if b_val == -1, step = 2; continue; end
                    
                    n_val = input('شماره مود n (برای TM عدد n>=0 و برای TE عدد n>=1): ');
                    if n_val == -1, step = 2; continue; end
                    
                    mode_type = input('نوع مود (1: TM, 2: TE): ');
                    if mode_type == -1, step = 2; continue; end
                    
                    if n_val < 0 || n_val ~= floor(n_val) || (mode_type == 2 && n_val == 0)
                        disp(' ');
                        disp('❌ خطای تعریف مود: مود TE0 در موجبر صفحه موازی وجود ندارد! (برای TM مقدار n>=0 مجاز است).');
                        input('جهت اصلاح ورودی‌ها، دکمه Enter را بزنید...', 's');
                        continue; 
                    end
                   
                    fc = (n_val * c) / (2 * b_val);
                    if f <= fc && n_val > 0
                        disp(' ');
                        disp('----------------------------------------------------');
                        fprintf('⛔ خطا: در فرکانس کاری f = %0.3e Hz، این مود انتشاری نیست!\n', f);
                        fprintf('📌 فرکانس قطع این مود: fc = %0.3e Hz می باشد.\n', fc);
                        disp('----------------------------------------------------');
                        input('جهت انتخاب فرکانس جدید، دکمه Enter را بزنید...', 's');
                        step = 2; 
                        continue;
                    end
                    
                   
                    if mode_type == 1 
                        if n_val == 0 
                            beta1 = w_val * sqrt(epcilone_val * miu_val);
                            E_z = sym(0);
                            E_y = E0 * sin(w*t - beta1*z);
                            E_x = sym(0); H_z = sym(0); H_y = sym(0);
                            H_x = -E0 * sqrt(epcilone/miu) * sin(w*t - beta1*z);
                        else
                            beta1 = sqrt(w_val^2*epcilone_val*miu_val - (n_val*pi/b_val)^2);
                            E_z = E0*sin(n_val*pi*y/b)*cos(w*t-beta1*z);
                            E_y = E0*beta1*b/(pi*n_val)*cos(n_val*pi*y/b)*sin(w*t-beta1*z);
                            E_x = sym(0); H_z = sym(0); H_y = sym(0);
                            H_x = -E0*w*epcilone*b/(pi*n_val)*cos(n_val*pi*y/b)*sin(w*t-beta1*z);
                        end
                    else 
                        beta1 = sqrt(w_val^2*epcilone_val*miu_val - (n_val*pi/b_val)^2);
                        E_z = sym(0); E_y = sym(0); E_x = -H0*w*miu*b/(pi*n_val)*sin(n_val*pi*y/b)*sin(w*t-beta1*z);
                        H_z = H0*cos(n_val*pi*y/b)*cos(w*t-beta1*z);
                        H_y = -H0*beta1*b/(pi*n_val)*sin(n_val*pi*y/b)*sin(w*t-beta1*z); H_x = sym(0);
                    end
                    
                    lambda_0 = c / f; z_max = 1.5 * lambda_0;
                    N_xy = 35; Nz = 30;
                    [X_grid, Y_grid, Z_grid] = meshgrid(linspace(0, b_val, N_xy), linspace(0, b_val, N_xy), linspace(0, z_max, Nz));
                    step = 4; 
                    
                case 2
                    a_val = input('طول a (متر): ');
                    if a_val == -1, step = 2; continue; end
                    
                    b_val = input('عرض b (متر): ');
                    if b_val == -1, step = 2; continue; end
                    
                    m_val = input('شماره مود m: ');
                    if m_val == -1, step = 2; continue; end
                    
                    n_val = input('شماره مود n: ');
                    if n_val == -1, step = 2; continue; end
                    
                    mode_type = input('نوع مود (1: TM, 2: TE): ');
                    if mode_type == -1, step = 2; continue; end
                   
                    if m_val < 0 || n_val < 0 || m_val ~= floor(m_val) || n_val ~= floor(n_val) || ...
                       (mode_type == 1 && (m_val == 0 || n_val == 0)) || ...
                       (mode_type == 2 && m_val == 0 && n_val == 0)
                        disp(' ');
                        disp('❌ خطای تعریف مود: برای TM باید m,n>=1 باشد و برای TE مود TE00 وجود ندارد!');
                        input('جهت اصلاح ورودی‌ها، دکمه Enter را بزنید...', 's');
                        continue;
                    end
                    
                    fc = (c / 2) * sqrt((m_val/a_val)^2 + (n_val/b_val)^2);
                    if f <= fc
                        disp(' ');
                        disp('----------------------------------------------------');
                        fprintf('⛔ خطا: در فرکانس کاری f = %0.3e Hz، این مود انتشاری نیست!\n', f);
                        fprintf('📌 فرکانس قطع این مود: fc = %0.3e Hz می باشد.\n', fc);
                        disp('----------------------------------------------------');
                        input('جهت انتخاب فرکانس جدید، دکمه Enter را بزنید...', 's');
                        step = 2;
                        continue;
                    end
                    
                    beta2 = sqrt(w_val^2*epcilone_val*miu_val - (m_val*pi/a_val)^2 - (n_val*pi/b_val)^2);
                    h_val = sqrt((m_val*pi/a_val)^2 + (n_val*pi/b_val)^2);
                    
                    if mode_type == 1 
                        E_z = E0*sin(m_val*pi*x/a)*sin(n_val*pi*y/b)*cos(w*t-beta2*z);
                        E_x = -E0*beta2*m_val*pi/a/(h_val^2)*cos(m_val*pi*x/a)*sin(n_val*pi*y/b)*sin(w*t-beta2*z);
                        E_y = -E0*beta2*n_val*pi/b/(h_val^2)*sin(m_val*pi*x/a)*cos(n_val*pi*y/b)*sin(w*t-beta2*z);
                        H_z = sym(0);
                        H_x = E0*w*epcilone*n_val*pi/b/(h_val^2)*sin(m_val*pi*x/a)*cos(n_val*pi*y/b)*sin(w*t-beta2*z);
                        H_y = -E0*w*epcilone*m_val*pi/a/(h_val^2)*cos(m_val*pi*x/a)*sin(n_val*pi*y/b)*sin(w*t-beta2*z);
                    else 
                        E_z = sym(0);
                        E_x = H0*w*miu*n_val*pi/b/(h_val^2)*cos(m_val*pi*x/a)*sin(n_val*pi*y/b)*sin(w*t-beta2*z);
                        E_y = -H0*w*miu*m_val*pi/a/(h_val^2)*sin(m_val*pi*x/a)*cos(n_val*pi*y/b)*sin(w*t-beta2*z);
                        H_z = H0*cos(m_val*pi*x/a)*cos(n_val*pi*y/b)*cos(w*t-beta2*z);
                        H_x = H0*beta2*m_val*pi/a/(h_val^2)*sin(m_val*pi*x/a)*cos(n_val*pi*y/b)*sin(w*t-beta2*z);
                        H_y = H0*beta2*n_val*pi/b/(h_val^2)*cos(m_val*pi*x/a)*sin(n_val*pi*y/b)*sin(w*t-beta2*z);
                    end
                    
                    lambda_0 = c / f; z_max = 1.5 * lambda_0;
                    N_xy = 35; Nz = 30;
                    [X_grid, Y_grid, Z_grid] = meshgrid(linspace(0, a_val, N_xy), linspace(0, b_val, N_xy), linspace(0, z_max, Nz));
                    step = 4;
                    
                case 3 
                    R_val = input('شعاع موجبر R (متر): ');
                    if R_val == -1, step = 2; continue; end
                    
                    n_val = input('شماره مود n (عدد صحیح نامنفی n>=0): ');
                    if n_val == -1, step = 2; continue; end
                    
                    p_val = input('شماره ریشه p (عدد صحیح مثبت p>=1): ');
                    if p_val == -1, step = 2; continue; end
                    
                    mode_type = input('نوع مود (1: TM, 2: TE): ');
                    if mode_type == -1, step = 2; continue; end
                 
                    if n_val < 0 || n_val ~= floor(n_val) || p_val < 1 || p_val ~= floor(p_val)
                        disp(' ');
                        disp('❌ خطای تعریف مود: اندیس n باید n>=0 و اندیس ریشه p باید p>=1 باشد!');
                        input('جهت اصلاح ورودی‌ها، دکمه Enter را بزنید...', 's');
                        continue;
                    end
                    
                    guess_range = [pi*(p_val-1+n_val/2), pi*(p_val+n_val/2)];
                    
                    if mode_type == 1 
                        root_val = fzero(@(x_val) besselj(n_val, x_val), guess_range);
                    else 
                        root_val = fzero(@(x_val) 0.5*(besselj(n_val-1, x_val)-besselj(n_val+1, x_val)), guess_range);
                    end
                    
                    fc = (root_val * c) / (2 * pi * R_val);
                    if f <= fc
                        disp(' ');
                        disp('----------------------------------------------------');
                        fprintf('⛔ خطا: در فرکانس کاری f = %0.3e Hz، این مود انتشاری نیست!\n', f);
                        fprintf('📌 فرکانس قطع این مود: fc = %0.3e Hz می باشد.\n', fc);
                        disp('----------------------------------------------------');
                        input('جهت انتخاب فرکانس جدید، دکمه Enter را بزنید...', 's');
                        step = 2;
                        continue;
                    end
                    
                    h_c = root_val / R_val;
                    beta3 = sqrt(w_val^2*miu_val*epcilone_val - h_c^2);
                    
                    if mode_type == 1 
                        E_z = E0*besselj(n_val, h_c*r)*cos(n_val*phi)*cos(w*t-beta3*z);
                        E_r = -E0*beta3/h_c*(0.5*(besselj(n_val-1,h_c*r)-besselj(n_val+1,h_c*r)))*cos(n_val*phi)*sin(w*t-beta3*z);
                        E_phi = E0*beta3*n_val/h_c^2/r*besselj(n_val,h_c*r)*sin(n_val*phi)*sin(w*t-beta3*z);
                        H_z = sym(0);
                        H_r = -E0*w*epcilone*n_val/h_c^2/r*besselj(n_val,h_c*r)*sin(n_val*phi)*sin(w*t-beta3*z);
                        H_phi = -E0*w*epcilone/h_c*(0.5*(besselj(n_val-1,h_c*r)-besselj(n_val+1,h_c*r)))*cos(n_val*phi)*sin(w*t-beta3*z);
                    else % TE
                        E_z = sym(0);
                        E_r = H0*w*miu*n_val/h_c^2/r*besselj(n_val,h_c*r)*sin(n_val*phi)*sin(w*t-beta3*z);
                        E_phi = H0*w*miu/h_c*(0.5*(besselj(n_val-1,h_c*r)-besselj(n_val+1,h_c*r)))*cos(n_val*phi)*sin(w*t-beta3*z);
                        H_z = H0*besselj(n_val, h_c*r)*cos(n_val*phi)*cos(w*t-beta3*z);
                        H_r = -H0*beta3/h_c*(0.5*(besselj(n_val-1,h_c*r)-besselj(n_val+1,h_c*r)))*cos(n_val*phi)*sin(w*t-beta3*z);
                        H_phi = H0*beta3*n_val/h_c^2/r*besselj(n_val,h_c*r)*sin(n_val*phi)*sin(w*t-beta3*z);
                    end
                    
                    E_x = E_r*cos(phi) - E_phi*sin(phi); E_y = E_r*sin(phi) + E_phi*cos(phi);
                    H_x = H_r*cos(phi) - H_phi*sin(phi); H_y = H_r*sin(phi) + H_phi*cos(phi);
                    
                    lambda_0 = c / f; z_max = 1.5 * lambda_0;
                    N_xy = 35; Nz = 30;
                    [X_grid, Y_grid, Z_grid] = meshgrid(linspace(-R_val, R_val, N_xy), linspace(-R_val, R_val, N_xy), linspace(0, z_max, Nz));
                    R_in = sqrt(X_grid.^2 + Y_grid.^2); R_in(R_in==0) = eps;
                    Phi_in = atan2(Y_grid, X_grid);
                    step = 4;
                    
                case 4 
                    disp('برای این ساختار فرمول‌بندی‌های TM(0,n) و TE(0,n) استفاده می‌شود.');
                    R_val = input('شعاع هسته فیبر R (متر): ');
                    if R_val == -1, step = 2; continue; end
                    
                    n_root = input('شماره ریشه n (عدد صحیح مثبت n>=1): ');
                    if n_root == -1, step = 2; continue; end
                    
                    if n_root < 1 || n_root ~= floor(n_root)
                        disp(' ');
                        disp('❌ خطای تعریف مود: شماره ریشه n باید عدد صحیح مثبت (n>=1) باشد!');
                        input('جهت اصلاح ورودی‌ها، دکمه Enter را بزنید...', 's');
                        continue;
                    end
                    
                    er1 = input('گذردهی نسبی هسته (epcilone_r1): ');
                    if er1 == -1, step = 2; continue; end
                    
                    er2 = input('گذردهی نسبی غلاف (epcilone_r2): ');
                    if er2 == -1, step = 2; continue; end
                    
                    if er1 <= er2
                        disp('❌ گذردهی هسته باید بزرگتر از غلاف باشد (er1 > er2).');
                        pause(2); continue;
                    end
                    
                    mode_type = input('نوع مود (1: TM, 2: TE): ');
                    if mode_type == -1, step = 2; continue; end
                    
                    n1 = sqrt(er1); n2 = sqrt(er2);
                    V_val = R_val*w_val/c*sqrt(n1^2 - n2^2);
                    
                    if mode_type == 1 
                        char_eq = @(u_val) besselj(1,u_val).*sqrt(V_val^2-u_val.^2).*besselk(0,sqrt(V_val^2-u_val.^2)) + ...
                            (er2/er1).*besselk(1,sqrt(V_val^2-u_val.^2)).*u_val.*besselj(0,u_val);
                    else 
                        char_eq = @(u_val) besselj(1,u_val).*sqrt(V_val^2-u_val.^2).*besselk(0,sqrt(V_val^2-u_val.^2)) + ...
                            besselk(1,sqrt(V_val^2-u_val.^2)).*u_val.*besselj(0,u_val);
                    end
                    
                    u_samples = linspace(1e-4, V_val-1e-4, 1000);
                    char_vals = char_eq(u_samples);
                    zero_crossings = find(char_vals(1:end-1) .* char_vals(2:end) <= 0);
                    
                    if length(zero_crossings) < n_root
                        disp(' ');
                        disp('----------------------------------------------------');
                        fprintf('⛔ خطا: در فرکانس کاری f = %0.3e Hz، هیچ مودی با ریشه n = %d انتشاری نیست!\n', f, n_root);
                        fprintf('📌 عدد V ساختار (V = %0.2f) کمتر از حد نیاز برای انتشار این مود است.\n', V_val);
                        disp('----------------------------------------------------');
                        input('جهت انتخاب فرکانس جدید، دکمه Enter را بزنید...', 's');
                        step = 2;
                        continue;
                    end
                    
                    u_guess = u_samples(zero_crossings(n_root));
                    u_root = fzero(char_eq, u_guess);
                    
                    W_val = sqrt(V_val^2 - u_root^2);
                    beta4 = sqrt((w_val*sqrt(miu_val*er1*epcilone_val))^2 - (u_root/R_val)^2);
                    
                    if mode_type == 1 
                        E_z_in = E0*besselj(0,u_root*r/R_val)*cos(w*t-beta4*z);
                        E_r_in = -E0*R_val*beta4/u_root*besselj(1,u_root*r/R_val)*sin(w*t-beta4*z);
                        E_phi_in = sym(0); H_z_in = sym(0); H_r_in = sym(0);
                        H_phi_in = -E0*w*er1*epcilone_val*R_val/u_root*besselj(1,u_root*r/R_val)*sin(w*t-beta4*z);
                        
                        E_z_out = E0*besselj(0,u_root)/besselk(0,W_val)*besselk(0,W_val*r/R_val)*cos(w*t-beta4*z);
                        E_r_out = E0*besselj(0,u_root)/besselk(0,W_val)*beta4*R_val/W_val*besselk(1,W_val*r/R_val)*sin(w*t-beta4*z);
                        E_phi_out = sym(0); H_z_out = sym(0); H_r_out = sym(0);
                        H_phi_out = E0*besselj(0,u_root)/besselk(0,W_val)*w*er2*epcilone_val*R_val/W_val*besselk(1,W_val*r/R_val)*sin(w*t-beta4*z);
                    else 
                        E_z_in = sym(0); E_r_in = sym(0); E_phi_in = -H0*w*miu_val*R_val/u_root*besselj(1,u_root*r/R_val)*sin(w*t-beta4*z);
                        H_z_in = H0*besselj(0,u_root*r/R_val)*cos(w*t-beta4*z); H_r_in = -H0*beta4*R_val/u_root*besselj(1,u_root*r/R_val)*sin(w*t-beta4*z); H_phi_in = sym(0);
                        E_z_out = sym(0); E_r_out = sym(0); E_phi_out = H0*besselj(0,u_root)/besselk(0,W_val)*w*miu_val*R_val/W_val*besselk(1,W_val*r/R_val)*sin(w*t-beta4*z);
                        H_z_out = H0*besselj(0,u_root)/besselk(0,W_val)*besselk(0,W_val*r/R_val)*cos(w*t-beta4*z); H_r_out = H0*besselj(0,u_root)/besselk(0,W_val)*beta4*R_val/W_val*besselk(1,W_val*r/R_val)*sin(w*t-beta4*z); H_phi_out = sym(0);
                    end
                    
                    E_z = E_z_in * heaviside(R_val - r) + E_z_out * heaviside(r - R_val);
                    E_r = E_r_in * heaviside(R_val - r) + E_r_out * heaviside(r - R_val);
                    E_phi = E_phi_in * heaviside(R_val - r) + E_phi_out * heaviside(r - R_val);
                    H_z = H_z_in * heaviside(R_val - r) + H_z_out * heaviside(r - R_val);
                    H_r = H_r_in * heaviside(R_val - r) + H_r_out * heaviside(r - R_val);
                    H_phi = H_phi_in * heaviside(R_val - r) + H_phi_out * heaviside(r - R_val);

                    E_x = E_r*cos(phi) - E_phi*sin(phi); E_y = E_r*sin(phi) + E_phi*cos(phi);
                    H_x = H_r*cos(phi) - H_phi*sin(phi); H_y = H_r*sin(phi) + H_phi*cos(phi);
                    
                    lambda_0 = c / f; z_max = 1.5 * lambda_0;
                    N_xy = 35; Nz = 30;
                    [X_grid, Y_grid, Z_grid] = meshgrid(linspace(-2.5*R_val, 2.5*R_val, N_xy), linspace(-2.5*R_val, 2.5*R_val, N_xy), linspace(0, z_max, Nz));
                    R_in = sqrt(X_grid.^2 + Y_grid.^2); R_in(R_in==0) = eps; 
                    Phi_in = atan2(Y_grid, X_grid);
                    step = 4;
            end
    end
end

%% 3
disp('در حال تبدیل روابط ریاضی به توابع عددی...');
if wg_type ~= 4
    subs_vars = [w, epcilone, miu, E0, H0]; subs_vals = [w_val, epcilone_val, miu_val, E0_val, H0_val];
    if wg_type == 1; subs_vars = [subs_vars, b]; subs_vals = [subs_vals, b_val]; end
    if wg_type == 2; subs_vars = [subs_vars, a, b]; subs_vals = [subs_vals, a_val, b_val]; end
else
    subs_vars = [w, E0, H0]; subs_vals = [w_val, E0_val, H0_val];
end

Ex_sub=subs(E_x, subs_vars, subs_vals); Ey_sub=subs(E_y, subs_vars, subs_vals); Ez_sub=subs(E_z, subs_vars, subs_vals);
Hx_sub=subs(H_x, subs_vars, subs_vals); Hy_sub=subs(H_y, subs_vars, subs_vals); Hz_sub=subs(H_z, subs_vars, subs_vals);

if wg_type <= 2
    v_in = [x, y, z, t];
else
    v_in = [r, phi, z, t];
end
Ex_f=matlabFunction(Ex_sub,'Vars',v_in); Ey_f=matlabFunction(Ey_sub,'Vars',v_in); Ez_f=matlabFunction(Ez_sub,'Vars',v_in);
Hx_f=matlabFunction(Hx_sub,'Vars',v_in); Hy_f=matlabFunction(Hy_sub,'Vars',v_in); Hz_f=matlabFunction(Hz_sub,'Vars',v_in);

%% 4
T_period = 2*pi/w_val;
frames_per_period = 40; 
num_periods = 3; 
t_array = linspace(0, num_periods*T_period, num_periods*frames_per_period);

figure('Name', 'Volumetric Space-Time EM Field', 'NumberTitle', 'off', 'Position', [50 50 1000 800]);

sq = 2; 
Xq = X_grid(1:sq:end, 1:sq:end, 1:sq:end); Yq = Y_grid(1:sq:end, 1:sq:end, 1:sq:end); Zq = Z_grid(1:sq:end, 1:sq:end, 1:sq:end);

x_sl = mean([min(X_grid(:)), max(X_grid(:))]); 
y_sl = mean([min(Y_grid(:)), max(Y_grid(:))]);
z_sl = linspace(0, z_max, 4);

hold on; grid on; view(-35, 35);

if wg_type == 4
    [Xc, Yc, Zc] = cylinder(R_val, 40);
    Zc = Zc * z_max;
    surf(Xc, Yc, Zc, 'FaceColor', 'cyan', 'FaceAlpha', 0.15, 'EdgeColor', 'none');
end

qE = quiver3(Xq, Yq, Zq, zeros(size(Xq)), zeros(size(Xq)), zeros(size(Xq)), 1.2, 'r', 'LineWidth', 1.2);
qH = quiver3(Xq, Yq, Zq, zeros(size(Xq)), zeros(size(Xq)), zeros(size(Xq)), 1.2, 'b', 'LineWidth', 1.2);

legend('Electric Field (E)', 'Magnetic Field (H)', 'Location', 'best');
xlabel('X-axis'); ylabel('Y-axis'); zlabel('Z-axis (Propagation)');
axis tight; colormap jet; colorbar;

%% 5
for i = 1:length(t_array)
    t_curr = t_array(i);
    
    if wg_type <= 2
        Ex_num=Ex_f(X_grid,Y_grid,Z_grid,t_curr); Ey_num=Ey_f(X_grid,Y_grid,Z_grid,t_curr); Ez_num=Ez_f(X_grid,Y_grid,Z_grid,t_curr);
        Hx_num=Hx_f(X_grid,Y_grid,Z_grid,t_curr); Hy_num=Hy_f(X_grid,Y_grid,Z_grid,t_curr); Hz_num=Hz_f(X_grid,Y_grid,Z_grid,t_curr);
    else
        Ex_num=Ex_f(R_in,Phi_in,Z_grid,t_curr); Ey_num=Ey_f(R_in,Phi_in,Z_grid,t_curr); Ez_num=Ez_f(R_in,Phi_in,Z_grid,t_curr);
        Hx_num=Hx_f(R_in,Phi_in,Z_grid,t_curr); Hy_num=Hy_f(R_in,Phi_in,Z_grid,t_curr); Hz_num=Hz_f(R_in,Phi_in,Z_grid,t_curr);
    end
    
    Ex_num = Ex_num.*ones(size(X_grid)); Ey_num = Ey_num.*ones(size(X_grid)); Ez_num = Ez_num.*ones(size(X_grid));
    Hx_num = Hx_num.*ones(size(X_grid)); Hy_num = Hy_num.*ones(size(X_grid)); Hz_num = Hz_num.*ones(size(X_grid));
    
    if wg_type == 3
        mask = R_in > R_val;
        Ex_num(mask) = nan; Ey_num(mask) = nan; Ez_num(mask) = nan;
        Hx_num(mask) = nan; Hy_num(mask) = nan; Hz_num(mask) = nan;
    end
    
    Exq = Ex_num(1:sq:end, 1:sq:end, 1:sq:end); Eyq = Ey_num(1:sq:end, 1:sq:end, 1:sq:end); Ezq = Ez_num(1:sq:end, 1:sq:end, 1:sq:end);
    Hxq = Hx_num(1:sq:end, 1:sq:end, 1:sq:end); Hyq = Hy_num(1:sq:end, 1:sq:end, 1:sq:end); Hzq = Hz_num(1:sq:end, 1:sq:end, 1:sq:end);
    
    E_mag = sqrt(abs(Ex_num).^2 + abs(Ey_num).^2 + abs(Ez_num).^2);
    
    set(qE, 'UData', Exq, 'VData', Eyq, 'WData', Ezq);
    set(qH, 'UData', Hxq, 'VData', Hyq, 'WData', Hzq);
    
    if exist('h_slice', 'var') && all(isvalid(h_slice))
        delete(h_slice);
    end
    h_slice = slice(X_grid, Y_grid, Z_grid, E_mag, x_sl, y_sl, z_sl);
    set(h_slice, 'EdgeColor', 'none', 'FaceAlpha', 0.6);
    
    if i == 1; clim([0, max(E_mag(:)) + 1e-6]); end
    title(sprintf('Volumetric Fields at t = %0.2e s', t_curr));
    drawnow;
end
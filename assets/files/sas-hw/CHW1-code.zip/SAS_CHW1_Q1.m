%domains difinition
n=-100:100;
m=1:100;
Ts=1/1000;
t=-10:Ts:10;
T=1:Ts:20;
t2=-pi/4:Ts:pi/4;
zeros(size(n));
evenMask=(mod(n,2)==0);
oddMask=~evenMask;
% signals of section 1.1 definition
s1=0.98.^n.*sin(0.2*pi*n+0.05*pi);
s2=zeros(size(n));
s2(evenMask)=ceil(sin(0.1*n(evenMask)).*exp(0.02*n(evenMask)));
s2(oddMask)=floor(cos(0.1*n(oddMask)).*exp(-0.02*n(oddMask)));
s3(m)=log10(m);

s4=zeros(1,201);
for nVal=-100:100
    pos_nVal=nVal+101;
    sum=0.0;
    for i=-100:nVal
        pos_i=i+101;
        neg_i=-i+101;
        sum=sum+s1(pos_i)*s2(neg_i);
    end
    s4(pos_nVal)=sum;
end
% signals of section 1.2 definition
s1_con=0.98.^t.*sin(0.2*pi*t+0.05*pi);
s3_con=log10(T);
% signals of section 1.3 definition
s5=exp(1j*0.5*pi*t);
s6=tanh(1j*pi*t2);
R_s5=real(s5);
I_s5=imag(s5);
A_s5=abs(s5);
P_s5=angle(s5);
R_s6=real(s6);
I_s6=imag(s6);
A_s6=abs(s6);
P_s6=angle(s6);
% plotting part
figure('Name','section 1.1 - discrete signal plotting');
subplot(2,2,1);
stem(n,s1,'filled','linewidth',1);
title('s1[n] signal');
xlabel('n (samples)');
ylabel('Amplitude');
grid on;

subplot(2,2,2);
stem(n,s2,'filled','linewidth',1);
title('s2[n] signal');
xlabel('n (samples)');
ylabel('Amplitude');
grid on;

subplot(2,2,3);
stem(m,s3,'filled','linewidth',1);
title('s3[m] signal');
xlabel('m (samples)');
ylabel('Amplitude');
grid on;

subplot(2,2,4);
stem(n,s4,'filled','linewidth',1);
title('s4[n] signal');
xlabel('n (samples)');
ylabel('Amplitude');
grid on;

figure('Name', 'section 1.2 - continuous signal plotting');
subplot(2,1,1);
plot(t,s1_con,'linewidth',1.2,'Color','red');
title('continuous s1(t) signal');
xlabel('t (seconds)');
ylabel('Amplitude');
grid on;

subplot(2,1,2);
plot(T,s3_con,'linewidth',1.2,'Color','blue');
title('continuous s2(t) signal');
xlabel('t (seconds)');
ylabel('Amplitude');
grid on;

figure('Name', 'section 1.3 - real, imaginary parts and Amplitude and Phase of s5 and plotting');
subplot(2,2,1);
plot(t,R_s5,'LineWidth',1,'Color','red');
title('real part of s5(t) signal');
xlabel('t (seconds)');
ylabel('real part');
grid on;

subplot(2,2,2);
plot(t,I_s5,'LineWidth',1,'Color','cyan');
title('imaginary part of s5(t) signal');
xlabel('t (seconds)');
ylabel('imaginary part');
grid on;

subplot(2,2,3);
plot(t,A_s5,'LineWidth',1,'Color','black');
title('amplitude of s5(t) signal');
xlabel('t (seconds)');
ylabel('Amplitude');
grid on;

subplot(2,2,4);
plot(t,P_s5,'LineWidth',1,'Color','green');
title('Pahse of s5(t) signal');
xlabel('t (seconds)');
ylabel('Phase (degree)');
grid on;

figure('Name', 'section 1.3 - real, imaginary parts and Amplitude and Phase of s6 and plotting');
subplot(2,2,1);
plot(t2,R_s6,'LineWidth',1,'Color','red');
title('real part of s6(t) signal');
xlabel('t (seconds)');
ylabel('real part');
grid on;

subplot(2,2,2);
plot(t2,I_s6,'LineWidth',1,'Color','cyan');
title('imaginary part of s6(t) signal');
xlabel('t (seconds)');
ylabel('imaginary part');
grid on;

subplot(2,2,3);
plot(t2,A_s6,'LineWidth',1,'Color','black');
title('amplitude of s6(t) signal');
xlabel('t (seconds)');
ylabel('Amplitude');
grid on;

subplot(2,2,4);
plot(t2,P_s6,'LineWidth',1,'Color','green');
title('Pahse of s6(t) signal');
xlabel('t (seconds)');
ylabel('Phase (degree)');
grid on;
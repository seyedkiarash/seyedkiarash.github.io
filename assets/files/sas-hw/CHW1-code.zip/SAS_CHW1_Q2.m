% domains definition
Ts=0.01;
t=-5:Ts:5;
% making requested signals
y1=ev_x(t);
y2=ev_x(t-2.5);
y3=ev_x(2*t);
y4=ev_x(0.5*t+3);
y5=ev_x(-1*(t-2));

y6=0.5*(ev_x(t)+ev_x(-1*t));
y7=0.5*(ev_x(t)-ev_x(-1*t));
%plotting signals
figure('Name','section 2.1 - x(t),x(t-2.5), x(2t), x(0.5t+3) and x(-(t-2)) plotting');
subplot(2,3,1);
plot(t,y1,'LineWidth',1,'Color','red');
title('x(t) signal');
xlabel('t (seconds)');
ylabel('Amplitude');
grid on;
ylim([-1.2, 1.2]);

subplot(2,3,2);
plot(t,y2,'LineWidth',1,'Color','blue');
title('x(t-2.5) signal');
xlabel('t (seconds)');
ylabel('Amplitude');
grid on;
ylim([-1.2, 1.2]);

subplot(2,3,3);
plot(t,y3,'LineWidth',1,'Color','green');
title('x(2t) signal');
xlabel('t (seconds)');
ylabel('Amplitude');
grid on;
ylim([-1.2, 1.2]);

subplot(2,3,4);
plot(t,y4,'LineWidth',1,'Color','magenta');
title('x(0.5t+3) signal');
xlabel('t (seconds)');
ylabel('Amplitude');
grid on;
ylim([-1.2, 1.2]);

subplot(2,3,5);
plot(t,y5,'LineWidth',1,'Color','black');
title('x(-(t-2)) signal');
xlabel('t (seconds)');
ylabel('Amplitude');
grid on;
ylim([-1.2, 1.2]);

figure('Name','section 2.2 - even and odd parts of x(t) plotting');
subplot(1,2,1);
plot(t,y6,'LineWidth',1.2,'Color','cyan');
title('even(x(t)) signal');
xlabel('t (seconds)');
ylabel('Amplitude');
grid on;
ylim([-1.2, 1.2]);

subplot(1,2,2);
plot(t,y7,'LineWidth',1.2,'Color','red');
title('odd(x(t)) signal');
xlabel('t (seconds)');
ylabel('Amplitude');
grid on;
ylim([-1.2, 1.2]);
%%%%%%%%%%
function out= ev_x(time)
t1=(time>=-5)&(time<-3);
t2=(time>=-3)&(time<-2);
t3=(time>=-2)&(time<2);
t4=(time>=2)&(time<4);
t5=(time>=4)&(time<5);

out=zeros(size(time));
out(t1)=0;
out(t2)=time(t2)+3;
out(t3)=1;
out(t4)=-0.5*time(t4)+2;
out(t5)=0;
end
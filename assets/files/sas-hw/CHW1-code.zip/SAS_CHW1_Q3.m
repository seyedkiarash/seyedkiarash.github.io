%%%section 1: test signals domains definition
Ts=0.01;
t1=-2:Ts:2;
t2=1:Ts:4;
%test signals difintion
x1=sin(0.35*pi*t1);
x2=exp(-1*t2.*t2);
%convolution result
my_conv(t1,t2,x1,x2,Ts,'section 3.1 - convolution of two arbitrary signals plotting','(x1*x2)(t)');

%%%section 2: signals domains difinition
T1=-2:Ts:4;
T1_rev=-4:Ts:2;
T2=-2:Ts:10;
T3=-20:Ts:20;
% signals difinition
x1_vec=ev_x1(T1);
x1_rev=ev_x1(-1*T1);
x2=exp(-0.5*(T2-0.5));
[ty1,y1]=my_conv(T1,T1_rev,x1_vec,x1_rev,Ts,'section 3.2 - convolution of given signals plotting','y1(t)=x1(t)*x1(-t)');
[ty2,y2]=my_conv(ty1,T2,y1,x2,Ts,'section 3.2 - convolution of given signals plotting','y2(t)=(y1*x2)(t)');
x3=dirac_detla(T3-5,Ts)+dirac_detla(T3+5,Ts);
[ty3_prime,y3_prime]=my_conv(ty1,T3,y1,x3,Ts,'section 3.2 - convolution of given signals plotting','y3_prime(t)=y1(t)*(dirac(t-5)+dirac(t+5))');
[ty3,y3]=my_conv(ty3_prime,ty2,y3_prime,y2,Ts,'section 3.2 - convolution of given signals plotting','y3(t)=(y3_prime*y2)(t)');
% checking results with matlab convolution function
[ty1_m,y1_m]=matlab_conv(T1,T1_rev,x1_vec,x1_rev,Ts,'section 3.2 - convolution of given signals plotting','y1(t)=x1(t)*x1(-t) with matlab convolution');
[ty2_m,y2_m]=matlab_conv(ty1,T2,y1,x2,Ts,'section 3.2 - convolution of given signals plotting','y2(t)=(y1*x2)(t) with matlab convolution');
[ty3_prime_m,y3_prime_m]=matlab_conv(ty1,T3,y1,x3,Ts,'section 3.2 - convolution of given signals plotting','y3_prime(t)=y1(t)*(dirac(t-5)+dirac(t+5)) with matlab convolution');
[ty3_m,y3_m]=matlab_conv(ty3_prime_m,ty2,y3_prime_m,y2,Ts,'section 3.2 - convolution of given signals plotting','y3(t)=(y3_prime*y2)(t) with matlab convolution');

%%%section 3: arbitrary signals and their domains difinition
t_=-10:Ts:10;
X1=sinc(t_);
X2=t_.*exp(-1*t_);
X3=5*t_.*t_;
X4=X2+X3;
% plotting results
[Ty1,y1_LSB]=my_conv(t_,t_,X1,X2,Ts,'section 3.3 - convolution of arbitrary signals plotting for verification relevance','y(t)=(x1*x2)(t)');
[~,y1_RSB]=my_conv(t_,t_,X2,X1,Ts,'section 3.3 - convolution of arbitrary signals plotting for verification relevance','y(t)=(x2*x1)(t)');
[~,y2_LSB]=my_conv(t_,t_,X1,X4,Ts,'section 3.3 - convolution of arbitrary signals plotting for verification relevance','y(t)=(x1*(x2+x3))(t)');
[~,y2_prime_RSB]=my_conv(t_,t_,X1,X3,Ts,'section 3.3 - convolution of arbitrary signals plotting for verification relevance','y(t)=(x1*x3)(t)');
y2_RSB=y2_prime_RSB+y1_LSB;
plotting(t_,y2_RSB,'section 3.3 - convolution of arbitrary signals plotting for verification relevance','y(t)=(x1*x2)(t)+(x1*x3)(t)')
[Ty3_prime,y3_prime_LSB]=my_conv(t_,t_,X2,X3,Ts,'section 3.3 - convolution of arbitrary signals plotting for verification relevance','y(t)=(x2*x3)(t)');
[~,y3_LSB]=my_conv(t_,Ty3_prime,X1,y3_prime_LSB,Ts,'section 3.3 - convolution of arbitrary signals plotting for verification relevance','y1(t)=(x1*(x2*x3))(t)');
[~,y3_RSB]=my_conv(Ty1,t_,y1_LSB,X3,Ts,'section 3.3 - convolution of arbitrary signals plotting for verification relevance','y1(t)=((x1*x2)*x3)(t)');

%functions
function [out_domain, out]=my_conv(x1_domain,x2_domain,x1,x2,dt,Name,plotTitle)
out_domain_1=x1_domain(1)+x2_domain(1);
out_domain_end=x1_domain(end)+x2_domain(end);
out_domain=out_domain_1:dt:out_domain_end;
N=length(x1)+length(x2)-1;
out=zeros(1,N);
for k=1:N
    sum=0;
    for i=1:length(x1)
        j=k-i+1;
        if (j>=1)&&(j<=length(x2))
            sum=sum+x1(i)*x2(j);
        end
    end
    out(k)=sum*dt;
end
figure('Name',Name)
plot(out_domain,out,'LineWidth',1,'Color','blue')
title(plotTitle);
ylabel('Amplitude');
xlabel('t (seconds)');
grid on;
end

function out=ev_x1(time)
    out=ones(size(time));
end

function out=dirac_detla(time,dt)
    out= zeros(size(time));
    [~,zero_idx]= min(abs(time)); 
    out(zero_idx) = 1/dt;
end

function plotting(domain,X,Name,plotTitle)
    figure('Name',Name);
    if length(domain) ~= length(X)
        domain = linspace(domain(1), domain(end), length(X));
    end
    plot(domain,X,'LineWidth',1,'Color','blue');
    title(plotTitle);
    ylabel('Amplitude');
    xlabel('t (seconds)');
    grid on

end
function [domain,out]=matlab_conv(t1,t2,x1,x2,dt,Name,plotTitle)
    out= conv(x1,x2)*dt;
    t_start= t1(1)+t2(1);
    t_end= t1(end)+t2(end);
    domain= linspace(t_start,t_end,length(out));

    figure('Name',Name)
    plot(domain,out,'LineWidth',1,'Color','blue')
    title(plotTitle);
    ylabel('Amplitude');
    xlabel('t (seconds)');
    grid on;
end
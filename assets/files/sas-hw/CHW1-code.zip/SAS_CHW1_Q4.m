%part 1 domains difinition
k=-49:50;
Ts=0.01;
t=-15:Ts:15;
a=zeros(size(k));

even=(mod(k,2)==0);
odd=~even;
%part 1 fourier coefficient
a(odd)=1/pi^2./(k(odd).*k(odd));
a(k==0)=0.75;
%part 2 signals difinition
x1=1-0.5*abs(mod(t+1,2)-1);

f_c=zeros(size(t));
for i=-49:50
    i_val=50+i;
    f_c=f_c+a(i_val)*expo(i,t);
end
%part 2 plotting the results
figure('Name','section 4.2 - fourier expresse of x1(t) with n=100');
plot(t,real(f_c),LineStyle='--',Color='black',LineWidth=1.5);
hold on;
plot(t,x1,Linewidth=1,Color='red');
title('comparison of x1(t) Fourier Reconstruction with n=100');
ylabel('Amplitude');
xlabel('t (second)');
legend('Fourier Approximation', 'Original Signal');
grid on;
%part 3 domains difinition
b=zeros(size(k));
%part 3 fourier coefficient
b(odd)=2/1j/pi./k(odd);
b(k==0)=0.00;
%part 3 signals difinition
x2 = sign(mod(t + 1, 2) - 1);

f_c2=zeros(size(t));
for i=-49:50
    i_val=50+i;
    f_c2=f_c2+b(i_val)*expo(i,t);
end
%part 3 plotting signals
figure('Name','section 4.3 - fourier expresse of x2(t) with n=100');
plot(t,real(f_c2),LineStyle='--',Color='blue',LineWidth=1.5);
hold on;
plot(t,x2,Linewidth=1,Color='green');
title('comparison of x2(t) Fourier Reconstruction with n=100');
ylabel('Amplitude');
xlabel('t (second)');
legend('Fourier Approximation', 'Original Signal');
grid on;
%part 4 definition and plotting signals
figure('Name','section 4.4 - fourier expresse of x2(t) with n=2,n=5,n=10,n=20,n=50,n=100');
plot(t,x2,Linewidth=1,Color='green',LineStyle='--');
hold on;
m_val=[2,5,10,20,50,100];
for m=m_val
    c=zeros(size(t));
    k_start=-floor(m/2);
    k_vals=k_start:(k_start+m-1);
        for k_val=k_vals
            if k_val==0
                b_val=0;
            elseif mod(k_val,2)~=0
                b_val=2/(1j*k_val*pi);
            else
                b_val=0;
            end
            c=c+b_val*expo(k_val,t);
        end
    plot(t,real(c),LineStyle='-',LineWidth=1.5);
end
title('comparison of x2(t) Fourier Reconstruction with n=100');
ylabel('Amplitude');
xlabel('t (second)');
legend('Original Signal x2(t)', 'M = 2', 'M = 5', 'M = 10', 'M = 20', 'M = 50', 'M = 100');
grid on;
%part 5 MSE error plotting
K=10:10:1000;
MSE1=zeros(size(k));
MSE2=zeros(size(K));
figure('Name','section 4.5 - MSE of Fourier Reconstruction with n=10,20,...,1000');
idx=1;
for M=K
    fs1=f_s1(M,t);
    fs2=f_s2(M,t);
    MSE1(idx)=my_MSE(x1,fs1);
    MSE2(idx)=my_MSE(x2,fs2);
    idx=idx+1;
end
plot(K,real(MSE1),LineWidth=1,Color='red');
hold on;
plot(K,real(MSE2),LineWidth=1,Color='blue');
title('MSE of Fourier Reconstruction with n=10,20,...,1000');
ylabel('MSE');
xlabel('K (number of coefficient)');
legend('Signal x1(t)', 'Signal x2(t)');
grid on;

%functions
function out=expo(k,time)
    out=exp(1j*pi*k*time);
end
function out=f_s2(k,time)
    for m=k
        out=zeros(size(time));
        k_start=-floor(m/2);
        k_vals=k_start:(k_start+m-1);
        for k_val=k_vals
            if k_val==0
                b_val=0;
            elseif mod(k_val,2)~=0
                b_val=2/(1j*k_val*pi);
            else
                b_val=0;
            end
            out=out+b_val*expo(k_val,time);
        end
    end
end
function out=f_s1(k,time)
    for m=k
        out=zeros(size(time));
        k_start=-floor(m/2);
        k_vals=k_start:(k_start+m-1);
        for k_val=k_vals
            if k_val==0
                a_val=0.75;
            elseif mod(k_val,2)~=0
                a_val=1/pi^2./(k_val.*k_val);
            else
                a_val=0;
            end
            out=out+a_val*expo(k_val,time);
        end
    end
end
function out=my_MSE(x_o,x_f)
    N=(length(x_o)-1)/2;
    m=-N:N;
    out=0.0;
    for n=m
        n_val=n+N+1;
        out=out+(x_o(n_val)-x_f(n_val))^2;
    end
    out=out/(2*N+1);
end
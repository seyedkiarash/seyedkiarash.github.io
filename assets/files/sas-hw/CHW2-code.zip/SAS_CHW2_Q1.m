%part 1: calculating the prajectory coordinate
syms t x0 y0 theta0 v0 vy vx

%part 2: plotting the projectile trajectory with two arbitrary angle
theta1=pi/3;
theta2=-1*pi/4;
y0=10;
x0=5;
v0=2;
figure(Name='Trajectories')
[x,y]=projectile(x0,y0,v0,theta1,t);
t_ac=solve(y==y0,t);
t_max=double(max(t_ac));
fplot(x,y);
hold on;
[x,y]=projectile(x0,y0,v0,theta2,t);
fplot(x,y)
t_ground=solve(y==0,t);
title('Projectile Trajectory');
xlabel('X coordinate');
ylabel('Y coordinate');
legend('Theta 1 (pi/3)','Theta 2 (-pi/4)');
grid on;
%part 3: velocity expression from x & y
Ts=0.01;
vx=diff(x,t);
vy=diff(y,t);
figure(Name='plotting vx and vy respect to the time')
fplot(vx);
hold on;
fplot(vy);
title('Vertical and Horizontal Velocity');
ylabel('Velocity');
xlabel('Time');
grid on;
legend('Horizontal (vx)','Vertical (vy)');

%functions
function [x,y]=projectile(x0,y0,v0,theta0,t)
    g=9.81;
    x=x0+v0*cos(theta0)*t;
    y=y0+v0*sin(theta0)*t-1/2*g*t^2;
end
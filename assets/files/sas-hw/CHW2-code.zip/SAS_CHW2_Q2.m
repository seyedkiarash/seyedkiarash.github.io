%part 1: definition of f(x) & g(x)
syms x w tau u eta
assume([x w tau u eta], 'real');
f=1/(1-x^3);
g=heaviside(x)*x^2*exp(-1*x);
figure(Name='plotting f(x) & g(x)')
fplot(f,[-10 10]);
hold on;
fplot(g, [-10 10]);
title('f & g');
xlabel('x');
ylabel('y');
legend('f=1/(1-x^3)','g=x^2*exp(-x)*u(x)');
grid on;
%part 2: computing Fourier Transform of f & g
F=fourier(f,x,w);
G=fourier(g,x,w);
F_m=abs(F);
F_ph=angle(F);
G_m=abs(G);
G_ph=angle(G);

figure(Name='plotting magnitude and phase of Fourier Transform of f & g')
subplot(2,2,1)
fplot(F_m, [-10 10]);
title('magnitude spectrum of Fourier Transform of f');
xlabel('w (freguency)')
ylabel('magmitude')
grid on;

subplot(2,2,2)
fplot(F_ph, [-10 10]);
title('phase spectrum of Fourier Transform of f');
xlabel('w (freguency)')
ylabel('phase')
grid on;

subplot(2,2,3)
fplot(G_m, [-10 10]);
title('magnitude spectrum of Fourier Transform of g');
xlabel('w (freguency)')
ylabel('magmitude')
grid on;

subplot(2,2,4)
fplot(G_ph, [-10 10]);
title('phase spectrum of Fourier Transform of g');
xlabel('w (freguency)')
ylabel('phase')
grid on;
%part 3: verification of relation
warning('off','MATLAB:integral:NonFiniteValue');
warning('off','MATLAB:integral:MinStepSize');
warning('off','MATLAB:integral:MaxIntervalCount');
LHS1_vals=zeros(1,N);
RHS1_vals=zeros(1,N);
for k=1:N
    wt=w_vec(k);
    RHS_sym=subs(F_w*G_w,w,wt);
    RHS1_vals(k)=double(vpa(RHS_sym,5)); 
    g_core=(x-tau)^2*exp(-(x-tau)); 
    integrand_x=subs(f,x,tau)*g_core*exp(-1i*wt*x);
    inner_int_sym=int(integrand_x,x,tau,inf);
    outer_func=matlabFunction(inner_int_sym,'Vars',tau);
    val_1=integral(outer_func,-50,0.99,'ArrayValued',true);
    val_2=integral(outer_func,1.01,50,'ArrayValued',true);
    LHS1_vals(k)=val_1+val_2;
end
warning('on','all');
figure('Name','Convolution Theorem Verification','NumberTitle','off');
subplot(2,1,1);
plot(w_vec,abs(LHS1_vals),'bo-','LineWidth',1.5,'MarkerSize',8); 
hold on;
plot(w_vec,abs(RHS1_vals),'rx--','LineWidth',1.5,'MarkerSize',8);
title('Magnitude: $\mathcal{F}\{f(x)*g(x)\}$ vs $F(\omega)G(\omega)$','Interpreter','latex','FontSize',12);
legend('LHS (Conv in Time)','RHS (Mult in Freq)','Location','best'); 
grid on;
xlabel('\omega'); 
ylabel('Magnitude');

subplot(2,1,2);
plot(w_vec,angle(LHS1_vals),'bo-','LineWidth',1.5,'MarkerSize',8); 
hold on;
plot(w_vec,angle(RHS1_vals),'rx--','LineWidth',1.5,'MarkerSize',8);
title('Phase Comparison');
legend('LHS Phase','RHS Phase','Location','best');
grid on;
xlabel('\omega'); ylabel('Phase (rad)');
warning('off', 'MATLAB:integral:NonFiniteValue');
warning('off', 'MATLAB:integral:MinStepSize');
warning('off', 'MATLAB:integral:MaxIntervalCount');
LHS2_vals=zeros(1,N);
RHS2_vals=zeros(1,N);
for k=1:N
    wt=w_vec(k);
    integrand_LHS2=f*g*exp(-1i*wt*x);
    LHS2_func=matlabFunction(integrand_LHS2,'Vars',x);
    val_left_1=integral(LHS2_func,0,0.99,'ArrayValued',true);
    val_left_2=integral(LHS2_func, 1.01,50,'ArrayValued',true);
    LHS2_vals(k)=val_left_1+val_left_2;
    conv_freq_integrand=subs(F_w,w,eta)*subs(G_w,w,wt-eta);
    RHS2_func=matlabFunction(conv_freq_integrand,'Vars',eta);
    RHS2_vals(k)=(1/(2*pi))*integral(RHS2_func,-50,50,'ArrayValued',true);
end
warning('on','all');
figure('Name','Modulation Theorem Verification','NumberTitle','off');
subplot(2,1,1);
plot(w_vec,abs(LHS2_vals),'bo-','LineWidth', 1.5,'MarkerSize',8); 
hold on;
plot(w_vec,abs(RHS2_vals),'rx--','LineWidth',1.5,'MarkerSize',8);
title('Magnitude: F\{f(x)g(x)\} vs (1/2\pi)[F(\omega)*G(\omega)]');
legend('LHS (Mult in Time)','RHS (Conv in Freq)','Location', 'best'); 
grid on;
xlabel('\omega'); 
ylabel('Magnitude');

subplot(2,1,2);
plot(w_vec, angle(LHS2_vals),'bo-','LineWidth',1.5,'MarkerSize',8);
hold on;
plot(w_vec,angle(RHS2_vals),'rx--','LineWidth',1.5,'MarkerSize',8);
title('Phase Comparison');
legend('LHS Phase','RHS Phase','Location','best'); 
grid on;
xlabel('\omega');
ylabel('Phase (rad)');






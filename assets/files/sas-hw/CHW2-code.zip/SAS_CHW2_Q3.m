%part 1: definition of f & g1 ... g6
syms x w
f=sin(pi*x)/(pi*x);
g1=subs(f,x,x-2);
g2=exp(1j*x/2)*f;
g3=subs(f,x,2*x);
g4=f*cos(2*x);
g5=diff(f,x);
g6=x*f;
%part 2: magnitude and phase spectrum of f & g1 ... g6
F=fourier(f,x,w);
G1=fourier(g1,x,w);
G2=fourier(g2,x,w);
G3=fourier(g3,x,w);
G4=fourier(g4,x,w);
G5=fourier(g5,x,w);
G6=fourier(g6,x,w);
F_m=abs(F);
F_ph=angle(F);
G1_m=abs(G1);
G1_ph=angle(G1);
G2_m=abs(G2);
G2_ph=angle(G2);
G3_m=abs(G3);
G3_ph=angle(G3);
G4_m=abs(G4);
G4_ph=angle(G4);
G5_m=abs(G5);
G5_ph=angle(G5);
G6_m=abs(G6);
G6_ph=angle(G6);
figure(Name='magnitude and phase spectrums');
subplot(3,2,1)
fplot(F_m,[-10 10]);
hold on;
fplot(G1_m,[-10 10]);
title('F & G1 mag');
ylabel('magnitude');
xlabel('w (frequency)');
legend('F mag','G1 mag');

subplot(3,2,2)
fplot(F_ph,[-10 10]);
hold on;
fplot(G1_ph,[-10 10]);
title('F & G1 phase');
ylabel('phase');
xlabel('w (frequency)');
legend('F phase','G1 phase');

subplot(3,2,3)
fplot(F_m,[-10 10]);
hold on;
fplot(G2_m,[-10 10]);
title('F & G2 mag');
ylabel('magnitude');
xlabel('w (frequency)');
legend('F mag','G2 mag');

subplot(3,2,4)
fplot(F_ph,[-10 10]);
hold on;
fplot(G2_ph,[-10 10]);
title('F & G2 phase');
ylabel('phase');
xlabel('w (frequency)');
legend('F phase','G2 pahse');

subplot(3,2,5)
fplot(F_m,[-10 10]);
hold on;
fplot(G3_m,[-10 10]);
title('F & G3 mag');
ylabel('magnitude');
xlabel('w (frequency)');
legend('F mag','G3 mag');

subplot(3,2,6)
fplot(F_ph,[-10 10]);
hold on;
fplot(G3_ph,[-10 10]);
title('F & G3 phase');
ylabel('phase');
xlabel('w (frequency)');
legend('F phase','G3 phase');

figure(Name='magnitude and phase spectrums 2');
subplot(3,2,1)
fplot(F_m,[-10 10]);
hold on;
fplot(G4_m,[-10 10]);
title('F & G4 mag');
ylabel('magnitude');
xlabel('w (frequency)');
legend('F mag','G4 mag');

subplot(3,2,2)
fplot(F_ph,[-10 10]);
hold on;
fplot(G4_ph,[-10 10]);
title('F & G4 phase');
ylabel('phase');
xlabel('w (frequency)');
legend('F phase','G4 phase');

subplot(3,2,3)
fplot(F_m,[-10 10]);
hold on;
fplot(G5_m,[-10 10]);
title('F & G5 mag');
ylabel('magnitude');
xlabel('w (frequency)');
legend('F mag','G5 mag');

subplot(3,2,4)
fplot(F_ph,[-10 10]);
hold on;
fplot(G5_ph,[-10 10]);
title('F & G5 phase');
ylabel('phase');
xlabel('w (frequency)');
legend('F phase','G5 phase');

subplot(3,2,5)
fplot(F_m,[-10 10]);
hold on;
fplot(G6_m,[-10 10]);
title('F & G6 mag');
ylabel('magnitude');
xlabel('w (frequency)');
legend('F mag','G6 mag');

subplot(3,2,6)
fplot(F_ph,[-10 10]);
hold on;
fplot(G6_ph,[-10 10]);
title('F & G6 phase');
ylabel('phase');
xlabel('w (frequency)');
legend('F phase','G6 phase');
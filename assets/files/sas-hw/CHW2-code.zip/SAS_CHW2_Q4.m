%part 1:f & g definition
n=-100:100;
f=(n>=-10)-(n>=10);
g=2.^abs(n);

%part 2: FFT of f & g
F=fft(ifftshift(f));
F_shifted=fftshift(F);
w=linspace(-pi,pi, length(n));
F_m=abs(F_shifted);
F_ph=angle(F_shifted);
G=fft(ifftshift(g));
G_shifted=fftshift(G);
G_m=abs(G_shifted);
G_ph=angle(G_shifted);
figure(Name='magnitude and phase of f & g spectrum');
subplot(2,2,1)
stem(w,F_m,'filled','linewidth',1);
title('magnitude of DFT of f');
ylabel('magnitude');
xlabel('w (frequency)');
grid on;

subplot(2,2,2)
stem(w,F_ph,'filled','linewidth',1);
title('phase of DFT of f');
ylabel('phase');
xlabel('w (frequency)');
grid on;

subplot(2,2,3)
stem(w,G_m,'filled','linewidth',1);
title('magnitude of DFT of g');
ylabel('magnitude');
xlabel('w (frequency)');
grid on;

subplot(2,2,4)
stem(w,G_ph,'filled','linewidth',1);
title('magnitude of DFT of g');
ylabel('phase');
xlabel('w (frequency)');
grid on;
%part 3: verification of relation
h_ev=(h(n)+h(-n))/2;
h_od=(h(n)-h(-n))/2;
H_ev=fft(ifftshift(h_ev));
H_od=fft(ifftshift(h_od));
H_ev_shifted=fftshift(H_ev);
H_od_shifted=-1j*fftshift(H_od);
h_=h(n);
H=fft(ifftshift(h_));
H_shifted=fftshift(H);
H_shifted_real=real(H_shifted);
H_shifted_imag=imag(H_shifted);
figure(Name='plotting real and imaginary part of H vs DFT of even and odd part of h');
subplot(2,1,1)
stem(w,H_shifted_real,'filled','LineWidth',1,'Color','green','LineStyle','-');
hold on;
stem(w,H_ev_shifted,'filled','LineWidth',1,'LineStyle','--','Color','red');
title('real part of DTF of h vs DTF of even part of h');
xlabel('w (frequency)');
ylabel('magnitude');
grid on;
legend('RE(F(h[n]))','F(EV(h[n]))');

subplot(2,1,2)
stem(w,H_shifted_imag,'filled','LineWidth',1,'Color','green','LineStyle','-');
hold on;
stem(w,H_od_shifted,'filled','LineWidth',1,'LineStyle','--','Color','red');
title('imaginary part of DTF of h vs DTF of odd part of h');
xlabel('w (frequency)');
ylabel('magnitude');
grid on;
legend('IM(F(h[n]))','F(OD(h[n]))');
function out=f_shift(n,n0)
    n_val=n+n0;
    out=(n_val>=-10)-(n_val>=10);
end

function out=g_shift(n,n0)
    n_val=n+n0;
    out=2.^abs(n_val);
end
function out=h(n)
    out=f_shift(n,20)+g_shift(n,-20);
end
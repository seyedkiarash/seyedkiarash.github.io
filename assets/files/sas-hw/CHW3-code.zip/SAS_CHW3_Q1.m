%part a
%defining laplace transform of impulse response h1 & h2
syms s
H1=(s-1)/(s^3+20*s^2+10*s+100);
H2=1/(s^4+20*s^2+10*s+100);
[N1,D1]=numden(H1);
[N2,D2]=numden(H2);
% determining zeros and poles of H1 & H2 and evalueting stablity of H1 & H2
poles1=solve(D1==0,s);
zeros1=solve(N1==0,s);
poles2=solve(D2==0,s);
zeros2=solve(N2==0,s);
p1=real(double(poles1));
p2=real(double(poles2));
flag1=false;
flag2=false;
for i=1:length(p1)
    if p1(i)>=0
        disp("system H1 isn't stable");
        flag1=false;
        break
    else
        flag1=true;
    
    end
end
if flag1
    disp("system H1 is stable");
end
for i=1:length(p2)
    if p2(i)>=0
        disp("system H2 isn't stable");
        flag2=false;
        break
    else
        flag2=true;
    
    end
end
if flag2
    disp("system H2 is stable");
end
% plotting zeros-poles diagram of H1 & H2
num_c1=sym2poly(N1);
den_c1=sym2poly(D1);
num_c2=sym2poly(N2);
den_c2=sym2poly(D2);
figure(Name='zeros-poles diagram of H1(s) & H2(s)')
subplot(2,1,1)
zplane(num_c1,den_c1);
title('zeros-poles diagram of H1(s)')
xlabel('Real part of s');
ylabel('imaginary part of s');
grid on;

subplot(2,1,2)
zplane(num_c2,den_c2);
title('zeros-poles diagram of H2(s)')
xlabel('Real part of s');
ylabel('imaginary part of s');
grid on;

%part b:
%defining H3(s)
S=tf('s');
H3=(S^2+3*S+5.5)*(S^2+4*S+6)*(S^2+0.2*S+0.01)/((S^2+3*S+5)*(S^2+4*S+3.1)*(S^2+0.2*S+1));
% plotting zeros-poles diagram of H3
figure(Name='zeros-poles diagram of H3(s)')
pzmap(H3);
title('zeros-poles diagram of H3(s)')
grid on;

%part c:
%defining step response of system h1 & h2
Y1=H1*1/s;
Y2=H2*1/s;
y1=ilaplace(Y1);
y2=ilaplace(Y2);
%plotting step response of system h1 & h2
figure(Name='step response of system h1 & system h2')
subplot(2,1,1)
fplot(y1,[0 40]);
title('step response of system h1')
xlabel('t (second)');
ylabel('amplitude');
grid on;

subplot(2,1,2)
fplot(y2, [0 40]);
title('step response of system h2')
xlabel('t (second)');
ylabel('amplitude');
grid on;

%part 4:
%defining G for a=[2,4,6] and plotting them
num=[2, 4.5];
figure(Name='step and impulse response of G')
subplot(2,1,1)
title('step response of G for a=[2, 4, 6]')
xlabel('t (second)');
ylabel('amplitude');
for a=[2, 4, 6]
    den=[3 a 7];
    G=tf(num,den);
    step(G);
    hold on;
end
legend('a=2','a=4','a=4');
grid on;

subplot(2,1,2)
title('impulse response of G for a=[2, 4, 6]')
xlabel('t (second)');
ylabel('amplitude');
for a=[2, 4, 6]
    den=[3 a 7];
    G=tf(num,den);
    impulse(G);
    hold on;
end
legend('a=2','a=4','a=4');
grid on;
%part a:
%defining x[n] signal
syms n z
x=sin(n*pi/4);
X=ztrans(x,n,z);
[N,D]=numden(X);
num_c=sym2poly(N);
den_c=sym2poly(D);
sys=tf(num_c,den_c,-1);
poles=pole(sys);
disp("maximum of amplitude of poles is: ");
disp(max(abs(poles)));
%plotting zeros-poles diagram of Z transform of x[n] 
figure(Name='zeros-poles diagram of X(z)')
pzmap(sys);
title('zeros-poles diagram');
grid on;

%part c:
%determinig partial fraction of H1(z)
b=[0,1];
a=[1,-2,0.5];
[r,p,k]=residuez(b,a);
n_val=0:50;
h1=zeros(size(n_val));
for i=1:length(r)
    h1=h1+r(i)*(p(i).^n_val);
end
for j=1:length(k)
    h1(j)=h1(j)+k(j);
end
%plotting Z inverse Transform of H1(z)
figure(Name='Z inverse Transform of H1(z)')
stem(n_val,real(h1),'filled','linewidth',1);
title('Z inverse Transform of H1(z)');
xlabel('n');
ylabel('amplitude');
grid on;

%part d:
%defining H1(z) symbolic
H1=z/(z^2-2*z+0.5);
h=iztrans(H1,z,n);
h_n=subs(h,n,n_val);
%plotting Z inverse Transform of H1(z)
figure(Name='Z inverse Transform of H1(z)')
stem(n_val,double(h_n),'filled','linewidth',1);
title('Z inverse Transform of H1(z)');
xlabel('n');
ylabel('amplitude');
grid on;
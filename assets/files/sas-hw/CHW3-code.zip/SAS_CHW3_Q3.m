%part a:
%bringing in the image
im=imread("IMG_20260311_093605.jpg");
imshow(im);
title('my image');
%part b:
%extracting RGB channels and comparision with original image
red_image=image(:,:,1);
green_image=image(:,:,2);
blue_image=image(:,:,3);
figure(Name='plotting RGB channels of The image')
subplot(2,2,1)
imshow(im);
title('original image');

subplot(2,2,2)
imshow(red_image);
title('red channel');

subplot(2,2,3)
imshow(green_image);
title('green channel');

subplot(2,2,4)
imshow(blue_image);
title('blue channel');

%part c:
%obtaning average of channels and RGB2gray of original image
es_im=uint8((double(red_image)+double(green_image)+double(blue_image))/3);
%plotting them next to each other
figure(Name='rgb2gray vs. average of RGB channels')
subplot(1,2,1)
rgb2g=rgb2gray(im);
imshow(rgb2g);
title('RGB2gray');

subplot(1,2,2)
imshow(es_im);
title('average of RGB channels');

%part d:
%defining Gx & Gy G based on the original picture
im2=imread("image.png");
T=[1 2 1;0 0 0;-1 -2 -1];
RGB2g=rgb2gray(im2);
Gy=conv2(double(RGB2g),T,'same');
Tt=transpose(T);
Gx=conv2(double(RGB2g),Tt,'same');
G=sqrt(Gx.^2+Gy.^2);
figure(Name='operating T on the original image');
subplot(1,2,1)
imshow(im2);
title('original image');

subplot(1,2,2)
imshow(uint8(G));
title('T(image)');
function samples = Fourier_Samples(Freq_vector , audio_vector , Fs)

% samples = Fourier_Samples(Freq_vector , audio_vector , Fs)
%
% You need to write a function that evaluates the Fourier samples of a 
% "Continuous-Domain" signal at the frequencies given in "Freq_vector". 
% "audio_vector" encapsulates the samples of this continuous-domain signal 
% captured with the sampling rate "Fs". 
% In simple words, if x(t) and X(w) denote the continuous-domain signal and
% its Fourier transform, respectively, by knowing the samples 
%                              x[n] = x(n/Fs)
% we would like to obtain the values X(2*pi * ff), where ff stands for the
% elements in "Freq_vector".
%
% "Freq_vector" is a vector of frequency values in Hz at which the Fourier
% samples are desired.
%
% "audio_vector" is the vector of samples of an audio signal.
%
% "Fs" is the sampling frequency (HZ) which is used for sampling the audio 
% signal.


% this is a random code to make the function work. You need to replace it
% with proper lines.
%samples         = randn(size(Freq_vector));


   audio_vector=audio_vector(:).';
   Freq_vector=Freq_vector(:).';
   N=length(audio_vector);
   k=0:(N-1);
   X=zeros(size(Freq_vector));
   for idx=1:length(Freq_vector)
       c=exp(-1j*2*pi*k/Fs*Freq_vector(idx));
        X(idx)=sum(audio_vector.*c)/Fs;
   end
   samples=X;
end

function output_samples = voice_siren_separator(vector_of_samples , Fs)

% output_samples = voice_siren_separator(vector_of_samples , Fs)
%
% The aim of this function is to separate the voice of the speaker from the
% siren in the background. Basically, this function applies a filter on the
% input. Your task is to design and implement such a filter, either by
% using difference systems or Fourier multiplication.
% (hint: the desired filter is band-stop; i.e., some frequecies in the 
%        middle that mainly contribute to the voice of siren should be 
%        blocked)
%
% "vector_of_samples" is a vector that contains the samples of the audio
% file. It can be either vertical or horizontal. If the elements are
% complex, the imaginary parts will be ignored.
%
% "Fs" is the sampling frequency (HZ) which is used for sampling the audio 
% signal.

% !!! Note: The following implementation is just an example to illustrate
% one possibility of implementing a filter. For a filter corresponding to
% the following difference system
%           \sum a_i * y[n-i] = \sum b_i * x[n-i]
% we denote the vectors of all a_i and b_i coefficients by "a_vec" and
% "b_vec", respectively. This way, the filter can be implemented by
    f1=720;%+
    f2=820;%+
    f3=1340;%+
    f4=1440;%+
    f5=1060;%+
    f6=1580;%+
    f8=960;%+
    f7=860;%+
    f9=1000;
    rw=0.95;
    rn=0.975;
    y1=filtering(f1,f2,f3,f4,f5,f6,f7,f8,f9,rw,rn,Fs,vector_of_samples);
    
    output_samples=filtering(f1,f2,f3,f4,f5,f6,f7,f8,f9,rw,rn,Fs,y1);
    
    
end

function [a_vec,b_vec]=Implementing_filter2(f1,f2,r,Fs)
    w1=2*pi*f1/Fs;
    w2=2*pi*f2/Fs;
    a_vec=[1,-2*r*(cos(w1)+cos(w2)),2*r^2*(1+2*cos(w1)*cos(w2)),-2*r^3*(cos(w1)+cos(w2)),r^4];
    b_vec=[1,-2*(cos(w1)+cos(w2)),2*(1+2*cos(w1)*cos(w2)),-2*(cos(w1)+cos(w2)),1];
end
function [a_vec,b_vec]=Implementing_filter1(f1,r,Fs)
    w1=2*pi*f1/Fs;
    a_vec=[1,-2*r*cos(w1),r^2];
    b_vec=[1,-2*cos(w1),1];
end
function output=filtering(f1,f2,f3,f4,f5,f6,f7,f8,f9,rw,rn,Fs,x)
    
    [a_vec1,b_vec1]=Implementing_filter2(f1,f8,rn,Fs);
    [a_vec2,b_vec2]=Implementing_filter2(f4,f3,rw,Fs);
    [a_vec3,b_vec3]=Implementing_filter2(f6,f5,rw,Fs);
    [a_vec4,b_vec4]=Implementing_filter2(f2,f7,rn,Fs);
    [a_vec5,b_vec5]=Implementing_filter1(f9,rw,Fs);
    y1=filter(b_vec1,a_vec1,x);
    y2=filter(b_vec2,a_vec2,y1);
    y3=filter(b_vec3,a_vec3,y2);
    y4=filter(b_vec5,a_vec5,y3);
    output=filter(b_vec4,a_vec4,y4);

end
function out=filtering1(f3,f4,f5,f6,f9,rw,Fs,x)
    [a_vec2,b_vec2]=Implementing_filter2(f4,f3,rw,Fs);
    [a_vec3,b_vec3]=Implementing_filter2(f6,f5,rw,Fs);
    [a_vec5,b_vec5]=Implementing_filter1(f9,rw,Fs);

    y2=filter(b_vec2,a_vec2,x);
    y3=filter(b_vec3,a_vec3,y2);
    out=filter(b_vec5,a_vec5,y3);
end
function out=filtering2(f1,f2,f7,f8,rn,Fs,x)
    [a_vec1,b_vec1]=Implementing_filter2(f1,f8,rn,Fs);
    [a_vec4,b_vec4]=Implementing_filter2(f2,f7,rn,Fs);
    y1=filter(b_vec1,a_vec1,x);
    out=filter(b_vec4,a_vec4,y1);
end